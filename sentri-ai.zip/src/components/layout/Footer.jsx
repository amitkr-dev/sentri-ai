import React from 'react'

export default function Footer() {
  return (
    <div className="p-4 text-zinc-400">
      Placeholder component for Footer
    </div>
  )
}
