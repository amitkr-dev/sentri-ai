import React from 'react'

export default function Spinner() {
  return (
    <div className="p-4 text-zinc-400">
      Placeholder component for Spinner
    </div>
  )
}
