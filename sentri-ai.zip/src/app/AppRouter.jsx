import React from 'react'
import RoutesIndex from '../routes/index'

export default function AppRouter() {
  return <RoutesIndex />
}
