import { useState } from 'react'
import { useLocation } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Search, Bell, ChevronDown, Command } from 'lucide-react'

const PAGE_META = {
  '/app/dashboard':     { title: 'Dashboard',      subtitle: 'Your AI command center' },
  '/app/tasks':         { title: 'Tasks',           subtitle: 'Everything you\'re working on' },
  '/app/risk':          { title: 'Risk Analysis',   subtitle: 'Portfolio-level risk across all tasks' },
  '/app/rescue':        { title: 'Rescue Mode',     subtitle: 'AI-driven crisis intervention' },
  '/app/calendar':      { title: 'Calendar',        subtitle: 'See what Sentri changed, and why' },
  '/app/analytics':     { title: 'Analytics',       subtitle: 'Patterns Sentri has learned about you' },
  '/app/copilot':       { title: 'AI Copilot',      subtitle: 'Ask anything. It can act, too.' },
  '/app/notifications': { title: 'Notifications',   subtitle: 'What needs your attention' },
  '/app/settings':      { title: 'Settings',        subtitle: 'Account, AI permissions, integrations' },
}

export default function Topbar() {
  const [focused, setFocused] = useState(false)
  const { pathname } = useLocation()
  const meta = PAGE_META[pathname] || PAGE_META['/app/dashboard']

  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="flex items-center justify-between px-6 py-4 border-b flex-shrink-0"
      style={{ background: 'rgba(9,9,11,0.8)', backdropFilter: 'blur(20px)', borderColor: 'rgba(255,255,255,0.07)' }}
    >
      {/* Left */}
      <div>
        <h1 className="text-lg font-bold text-white leading-tight">{meta.title}</h1>
        <p className="text-xs text-zinc-500 mt-0.5">{meta.subtitle}</p>
      </div>

      {/* Right */}
      <div className="flex items-center gap-3">
        {/* Search */}
        <div className="relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 pointer-events-none transition-colors duration-200"
            style={{ color: focused ? '#6366f1' : undefined }} />
          <input
            type="text"
            placeholder="Search tasks..."
            onFocus={() => setFocused(true)}
            onBlur={() => setFocused(false)}
            className="w-52 text-sm bg-white/5 border rounded-xl pl-8 pr-16 py-2 text-zinc-300 placeholder-zinc-600 outline-none transition-all duration-200"
            style={{
              borderColor: focused ? 'rgba(99,102,241,0.6)' : 'rgba(255,255,255,0.08)',
              boxShadow: focused ? '0 0 0 3px rgba(99,102,241,0.12)' : 'none',
            }}
          />
          {!focused && (
            <span className="absolute right-2.5 top-1/2 -translate-y-1/2 flex items-center gap-0.5 text-xs text-zinc-600 pointer-events-none">
              <Command size={10} />K
            </span>
          )}
        </div>

        {/* Bell */}
        <button className="relative w-9 h-9 rounded-xl flex items-center justify-center text-zinc-400 hover:text-white transition-all duration-200 hover:bg-white/8"
          style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}>
          <Bell size={16} />
          <span className="absolute top-2 right-2 w-1.5 h-1.5 rounded-full bg-primary" style={{ boxShadow: '0 0 6px rgba(99,102,241,0.8)' }} />
        </button>

        {/* Avatar */}
        <div className="flex items-center gap-2 cursor-pointer group">
          <div className="relative">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-violet-500 flex items-center justify-center text-sm font-bold text-white">A</div>
            <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-accent border-2 border-bg" />
          </div>
          <ChevronDown size={14} className="text-zinc-500 group-hover:text-zinc-300 transition-colors" />
        </div>
      </div>
    </motion.header>
  )
}
