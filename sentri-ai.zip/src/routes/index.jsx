import React from 'react'
import { BrowserRouter } from 'react-router-dom'
import AppRoutes from './AppRoutes'

export default function RoutesIndex() {
  return (
    <BrowserRouter>
      <AppRoutes />
    </BrowserRouter>
  )
}
